<?php
	include "../../koneksi.php";
	$kode_customer = $_GET['kode_customer'];
	$query = mysqli_query($sambungin,"DELETE FROM tbcustomer where kode_customer='$kode_customer'") or die (mysql_error());

	 echo "
        <meta http-equiv='refresh' content = '0; url=../beranda.php?hal=dataCustomer'>
      ";
?>