 <section id="main-content">
      <section class="wrapper">
		<div class="col-md-6">
			<div class="form-panel">
				<h3><i class="fa fa-file-o"></i> Laporan Transaksi Pembelian</h3>
					<form method="POST" action="laporan/laporanPenerimaan.php" style="font-size: 18px;">
						<div class="form-group">
							<label style="font-weight:bold;">Tanggal Awal</label>
							<input class="form-control" style="font-size: 15px;" type="date" name="tgl_awal">
						</div>
						<div class="form-group">
							<label style="font-weight:bold;">Tanggal Akhir</label>
							<input class="form-control" style="font-size: 15px;" type="date" name="tgl_akhir">
						</div>

						<div class="form-group">
						<button class="btn btn-primary" name="cetakPenerimaan"><i class="fa fa-print"></i> Cetak</button>
						</div>
						
					</form>

			</div> <!--  Akhir Panel -->
			
		</div>
		<div class="col-md-6">
			<div class="form-panel">
				<h3><i class="fa fa-file-o"></i> Laporan Transaksi Penjualan</h3>
					<form method="POST" action="laporan/laporanPengeluaran.php" style="font-size: 18px;">
						<div class="form-group">
							<label style="font-weight:bold;">Tanggal Awal</label>
							<input class="form-control" style="font-size: 15px;" type="date" name="tgl_awal">
						</div>
						<div class="form-group">
							<label style="font-weight:bold;">Tanggal Akhir</label>
							<input class="form-control" style="font-size: 15px;" type="date" name="tgl_akhir">
						</div>

						<div class="form-group">
						<button class="btn btn-primary" name="cetakPenerimaan"><i class="fa fa-print"></i> Cetak</button>
						</div>
						
					</form>

			</div> <!--  Akhir Panel -->
			
		</div>



	  </section>
</section>