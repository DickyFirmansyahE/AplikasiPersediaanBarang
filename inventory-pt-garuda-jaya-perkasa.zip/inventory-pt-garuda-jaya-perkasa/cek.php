<?php

if(isset($_SESSION['log'])){

}else{
    header('location:../index.php');
};
