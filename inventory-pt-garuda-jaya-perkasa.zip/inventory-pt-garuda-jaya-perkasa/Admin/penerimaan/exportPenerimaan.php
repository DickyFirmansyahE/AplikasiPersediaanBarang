<?php
include "../fungsiExport.php";
include "../../koneksi.php";

$hasil = mysqli_query($sambungin,"SELECT * From tbpenerimaan left join tbsupplier on tbpenerimaan.kode_supplier = tbsupplier.kode_supplier left join tblogin on tbpenerimaan.id_login = tblogin.id_login");

$namafile = "DataPenerimaan.xls";
$judul = "Daftar Penerimaan Barang";
$tablehead = 2;
$tablebody = 3;
$nourut = 1;

//tulis header ms excel
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
header("Content-Type : application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Disposition: attachment;filename=".$namafile."");
header("Content-Transfer-Encoding: binary");
xlsBOF();
xlsWriteLabel(0,0,$judul);
$kolomhead = 0;

xlsWriteLabel($tablehead,$kolomhead++,"No");
xlsWriteLabel($tablehead,$kolomhead++,"Kode Terima");
xlsWriteLabel($tablehead,$kolomhead++,"Tanggal");
xlsWriteLabel($tablehead,$kolomhead++,"Nama Supplier");
xlsWriteLabel($tablehead,$kolomhead++,"Admin");

while($data = mysqli_fetch_array($hasil)){

$kolombody = 0;

xlsWriteLabel($tablebody,$kolombody++,$nourut);
xlsWriteLabel($tablebody,$kolombody++,$data['kode_terima']);
xlsWriteLabel($tablebody,$kolombody++,$data['tanggal_terima']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_supplier']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_admin']);

$tablebody++;
$nourut++;
}
xlsEOF();
exit();



?>