<?php

$kode_kategori = $_GET['kode_kategori'];


if ($_SERVER['REQUEST_METHOD'] == "POST") {
  include "../koneksi.php";
  $kode_kategori = $_POST['kode_kategori'];
  $nama_kategori = $_POST['nama_kategori'];

  $simpan = mysqli_query($sambungin, "UPDATE tbkategori SET nama_kategori = '$nama_kategori' where kode_kategori='$kode_kategori'");

  echo "
        <script>
        window.alert('Data Kategori Berhasil Diubah !!')
        </script>
      ";


  echo "
        <meta http-equiv='refresh' content = '0; url=?hal=dataKategori'>
      ";
}

?>

<section id="main-content">
  <section class="wrapper">
    <!-- BASIC FORM ELELEMNTS -->

    <?php
    include "../koneksi.php";
    $query = mysqli_query($sambungin, "SELECT * FROM tbkategori where kode_kategori = '$kode_kategori'");

    while ($data = mysqli_fetch_array($query)) {
    ?>
      <div class="row mt">
        <div class="col-lg-12">
          <div class="form-panel">
            <h4 style="font-size: 25px;"><i class="bi bi-tags"></i> Ubah Kategori</h4>
            <hr class="mb">
            <form class="form-horizontal style-form" method="post" style="padding: 10px 100px; font-size: 18px;">

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Kode Kategori</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="kode_kategori" value="<?php echo $data['kode_kategori'] ?>" readonly>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Nama Kategori</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="nama_kategori" value="<?php echo $data['nama_kategori'] ?>">
                </div>
              </div>


              <div class="form-group">
                <div class="col-sm-4">
                  <button class="btn btn-primary" name="">Simpan</button>
                  <a href="?hal=dataKategori" class="btn btn-warning">Kembali</a>
                </div>
              </div>
            </form>

          <?php
        }
          ?>
          </div>
        </div>
        <!-- col-lg-12-->
      </div>


  </section>
</section>