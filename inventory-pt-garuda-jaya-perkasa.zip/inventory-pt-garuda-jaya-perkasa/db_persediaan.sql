-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2022 at 06:33 PM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_persediaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbbarang`
--

CREATE TABLE `tbbarang` (
  `kode_barang` varchar(6) NOT NULL,
  `nama_barang` varchar(30) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `kode_kategori` varchar(6) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `stok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbbarang`
--

INSERT INTO `tbbarang` (`kode_barang`, `nama_barang`, `satuan`, `kode_kategori`, `harga_jual`, `harga_beli`, `stok`) VALUES
('ALM001', 'Alumunium Foil', 'Centimeter', 'KTG002', 12000, 10000, 25),
('ALM002', 'Alumunium List', 'Meter', 'KTG002', 30000, 25000, 20);

-- --------------------------------------------------------

--
-- Table structure for table `tbcustomer`
--

CREATE TABLE `tbcustomer` (
  `kode_customer` varchar(6) NOT NULL,
  `nama_customer` varchar(30) NOT NULL,
  `contact_person` varchar(30) NOT NULL,
  `no_telp` varchar(12) NOT NULL,
  `alamat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbcustomer`
--

INSERT INTO `tbcustomer` (`kode_customer`, `nama_customer`, `contact_person`, `no_telp`, `alamat`) VALUES
('CUS001', 'PT. SULAIMAN', 'Ilham', '081314567788', 'Bekasi'),
('CUS002', 'PT. Kurniawan GG', 'Jamal', '02133204291', 'Jl. Bujug Dah');

-- --------------------------------------------------------

--
-- Table structure for table `tbdetail_penerimaan`
--

CREATE TABLE `tbdetail_penerimaan` (
  `id` int(11) NOT NULL,
  `kode_terima` varchar(20) NOT NULL,
  `kode_barang` varchar(6) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `harga_pokok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbdetail_penerimaan`
--

INSERT INTO `tbdetail_penerimaan` (`id`, `kode_terima`, `kode_barang`, `jumlah_barang`, `harga_pokok`) VALUES
(1, 'INV202206170001', 'ALM002', 2, 90000),
(2, 'INV202206170002', 'ALM001', 2, 50000),
(3, 'INV202206170003', 'ALM001', 2, 45000),
(4, 'INV202206170003', 'ALM002', 1, 60000);

-- --------------------------------------------------------

--
-- Table structure for table `tbdetail_pengeluaran`
--

CREATE TABLE `tbdetail_pengeluaran` (
  `id` int(11) NOT NULL,
  `kode_keluar` varchar(20) NOT NULL,
  `kode_barang` varchar(6) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `harga_satuan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbdetail_pengeluaran`
--

INSERT INTO `tbdetail_pengeluaran` (`id`, `kode_keluar`, `kode_barang`, `jumlah_barang`, `harga_satuan`) VALUES
(7, 'FKT202206170001', 'ALM001', 3, 89000),
(8, 'FKT202206170002', 'ALM001', 6, 90000),
(9, 'FKT202206170003', 'ALM002', 2, 89000);

-- --------------------------------------------------------

--
-- Table structure for table `tbgabung_transaksi`
--

CREATE TABLE `tbgabung_transaksi` (
  `id` int(11) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `kode_barang` varchar(6) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `ket` varchar(20) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbgabung_transaksi`
--

INSERT INTO `tbgabung_transaksi` (`id`, `kode`, `tanggal`, `kode_barang`, `jumlah_barang`, `ket`, `waktu`) VALUES
(161, 'FKT202206170001', '2022-06-17', 'ALM001', 3, 'KELUAR', '2022-06-17 05:36:40'),
(162, 'FKT202206170001', '2022-06-17', 'ALM001', 0, 'MASUK', '2022-06-17 05:36:40'),
(163, 'INV202206170001', '2022-06-17', 'ALM002', 2, 'MASUK', '2022-06-17 08:46:58'),
(164, 'INV202206170001', '2022-06-17', 'ALM002', 0, 'KELUAR', '2022-06-17 08:46:58'),
(165, 'INV202206170002', '2022-06-17', 'ALM001', 2, 'MASUK', '2022-06-17 09:01:11'),
(166, 'INV202206170002', '2022-06-17', 'ALM001', 0, 'KELUAR', '2022-06-17 09:01:11'),
(167, 'INV202206170003', '2022-06-17', 'ALM001', 2, 'MASUK', '2022-06-17 09:01:58'),
(168, 'INV202206170003', '2022-06-17', 'ALM002', 1, 'MASUK', '2022-06-17 09:01:58'),
(170, 'INV202206170003', '2022-06-17', 'ALM001', 0, 'KELUAR', '2022-06-17 09:01:58'),
(171, 'INV202206170003', '2022-06-17', 'ALM002', 0, 'KELUAR', '2022-06-17 09:01:58'),
(173, 'FKT202206170002', '2022-06-17', 'ALM001', 6, 'KELUAR', '2022-06-17 10:45:14'),
(174, 'FKT202206170002', '2022-06-17', 'ALM001', 0, 'MASUK', '2022-06-17 10:45:14'),
(175, 'FKT202206170003', '2022-06-17', 'ALM002', 2, 'KELUAR', '2022-06-17 16:19:12'),
(176, 'FKT202206170003', '2022-06-17', 'ALM002', 0, 'MASUK', '2022-06-17 16:19:12');

-- --------------------------------------------------------

--
-- Table structure for table `tbkategori`
--

CREATE TABLE `tbkategori` (
  `kode_kategori` varchar(6) NOT NULL,
  `nama_kategori` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbkategori`
--

INSERT INTO `tbkategori` (`kode_kategori`, `nama_kategori`) VALUES
('KTG001', 'Ribeen'),
('KTG002', 'LIST U');

-- --------------------------------------------------------

--
-- Table structure for table `tblogin`
--

CREATE TABLE `tblogin` (
  `id_login` varchar(6) NOT NULL,
  `username` varchar(12) NOT NULL,
  `password` varchar(12) NOT NULL,
  `nama_admin` varchar(50) NOT NULL,
  `status_admin` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblogin`
--

INSERT INTO `tblogin` (`id_login`, `username`, `password`, `nama_admin`, `status_admin`) VALUES
('ADM001', 'Dicky', 'dicky191', 'Dicky Firmansyah', '1'),
('ADM002', 'Naufal', 'naufal123', 'Naufal', '1'),
('ADM003', 'Akmal', 'akmal101', 'Akmal Raharjo', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbpenerimaan`
--

CREATE TABLE `tbpenerimaan` (
  `kode_terima` varchar(20) NOT NULL,
  `tanggal_terima` date NOT NULL,
  `jumlah_item` int(11) NOT NULL,
  `kode_supplier` varchar(6) NOT NULL,
  `id_login` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbpenerimaan`
--

INSERT INTO `tbpenerimaan` (`kode_terima`, `tanggal_terima`, `jumlah_item`, `kode_supplier`, `id_login`) VALUES
('INV202206170001', '2022-06-17', 1, 'SUP002', 'ADM001'),
('INV202206170002', '2022-06-17', 1, 'SUP002', 'ADM001'),
('INV202206170003', '2022-06-17', 2, 'SUP002', 'ADM001');

-- --------------------------------------------------------

--
-- Table structure for table `tbpengeluaran`
--

CREATE TABLE `tbpengeluaran` (
  `kode_keluar` varchar(20) NOT NULL,
  `tanggal_keluar` date NOT NULL,
  `jumlah_item` int(11) NOT NULL,
  `kode_customer` varchar(6) NOT NULL,
  `id_login` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbpengeluaran`
--

INSERT INTO `tbpengeluaran` (`kode_keluar`, `tanggal_keluar`, `jumlah_item`, `kode_customer`, `id_login`) VALUES
('FKT202206170001', '2022-06-17', 1, 'CUS002', 'ADM001'),
('FKT202206170002', '2022-06-17', 1, 'CUS001', 'ADM001'),
('FKT202206170003', '2022-06-17', 1, 'CUS002', 'ADM001');

-- --------------------------------------------------------

--
-- Table structure for table `tbsementara`
--

CREATE TABLE `tbsementara` (
  `id` int(11) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `kode_barang` varchar(6) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbsupplier`
--

CREATE TABLE `tbsupplier` (
  `kode_supplier` varchar(6) NOT NULL,
  `nama_supplier` varchar(30) NOT NULL,
  `contact_person` varchar(30) NOT NULL,
  `no_telp` varchar(12) NOT NULL,
  `alamat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbsupplier`
--

INSERT INTO `tbsupplier` (`kode_supplier`, `nama_supplier`, `contact_person`, `no_telp`, `alamat`) VALUES
('SUP001', 'PT. Maju Mundur', 'Jamal Saripudin', '081314667989', 'Jl. Abdul Karim 5, Jakarta Selatan'),
('SUP002', 'PT. Gundaria', 'Mamat', '08581394034', 'Jl. Padang Pasir');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbbarang`
--
ALTER TABLE `tbbarang`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indexes for table `tbcustomer`
--
ALTER TABLE `tbcustomer`
  ADD PRIMARY KEY (`kode_customer`);

--
-- Indexes for table `tbdetail_penerimaan`
--
ALTER TABLE `tbdetail_penerimaan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbdetail_pengeluaran`
--
ALTER TABLE `tbdetail_pengeluaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbgabung_transaksi`
--
ALTER TABLE `tbgabung_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbkategori`
--
ALTER TABLE `tbkategori`
  ADD PRIMARY KEY (`kode_kategori`);

--
-- Indexes for table `tblogin`
--
ALTER TABLE `tblogin`
  ADD PRIMARY KEY (`id_login`);

--
-- Indexes for table `tbpenerimaan`
--
ALTER TABLE `tbpenerimaan`
  ADD PRIMARY KEY (`kode_terima`);

--
-- Indexes for table `tbpengeluaran`
--
ALTER TABLE `tbpengeluaran`
  ADD PRIMARY KEY (`kode_keluar`);

--
-- Indexes for table `tbsementara`
--
ALTER TABLE `tbsementara`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbsupplier`
--
ALTER TABLE `tbsupplier`
  ADD PRIMARY KEY (`kode_supplier`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbdetail_penerimaan`
--
ALTER TABLE `tbdetail_penerimaan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbdetail_pengeluaran`
--
ALTER TABLE `tbdetail_pengeluaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbgabung_transaksi`
--
ALTER TABLE `tbgabung_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=177;
--
-- AUTO_INCREMENT for table `tbsementara`
--
ALTER TABLE `tbsementara`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
