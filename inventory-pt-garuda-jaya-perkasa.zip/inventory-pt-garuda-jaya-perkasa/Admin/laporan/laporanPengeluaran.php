<?php
	include "../../koneksi.php";
	include "../../fpdf17/fpdf.php";
	include "../fungsiTanggal.php";
	$tgl_awal = $_POST['tgl_awal'];
	$tgl_akhir = $_POST['tgl_akhir'];

$pdf = new FPDF ('L','mm',array(297,420)); // tipe kertas P portrait, L lanscape , mm milimeter , 210,297 ukuran kertas 
$pdf->addPage();

$pdf-> SetFont('Arial','B',18); // tipe font , bold , ukuran font
$pdf-> Cell(120);
$pdf->Cell(155,10,'PT. Garuda Jaya Perkasa', 0,1,'C');
$pdf-> SetFont('Arial','B',18); // tipe font , bold , ukuran font
$pdf-> Cell(120);
$pdf->Cell(155,10,'Laporan Penjualan Barang', 0,1,'C');
$pdf-> SetFont('Arial','',14); // tipe font , bold , ukuran font
$pdf-> Cell(120);
$pdf->Cell(155,10,tgl_indo($tgl_awal).' s.d '.tgl_indo($tgl_akhir), 0,1,'C');

$pdf->Ln(2);
$pdf-> SetFont('Arial','B',12); // tipe font , bold , ukuran font
$pdf->Cell(20);
$pdf->Cell(10,6,'No',1,0,'L');
$pdf->Cell(35,6,'Tanggal',1,0,'L');
$pdf->Cell(45,6,'No Faktur',1,0,'L');
$pdf->Cell(85,6,'Nama Customer',1,0,'L');
$pdf->Cell(70,6,'Nama Barang',1,0,'L');
$pdf->Cell(20,6,'Satuan',1,0,'L');
$pdf->Cell(15,6,'Qty',1,0,'L');
$pdf->Cell(40,6,'Harga Satuan',1,0,'L');
$pdf->Cell(40,6,'Jumlah',1,0,'L');

$no = 1;
$total_harga_pokok = 0;
$query = mysqli_query($sambungin,"SELECT  * FROM tbdetail_pengeluaran left join tbpengeluaran on tbdetail_pengeluaran.kode_keluar = tbpengeluaran.kode_keluar left join tbbarang on tbdetail_pengeluaran.kode_barang = tbbarang.kode_barang left join tbcustomer on tbpengeluaran.kode_customer = tbcustomer.kode_customer where (tbpengeluaran.tanggal_keluar BETWEEN '$tgl_awal' AND '$tgl_akhir' )");
while ($data = mysqli_fetch_array($query)){
	$jumlahharga = $data['jumlah_barang'] * $data['harga_satuan'];
	$total_harga_pokok += $jumlahharga;

	$pdf->Ln(6);
	$pdf-> SetFont('Arial','',12); // tipe font , bold , ukuran font
	$pdf->Cell(20);
	$pdf->Cell(10,6,$no++,1,0,'L');
	$pdf->Cell(35,6,tgl_indo($data['tanggal_keluar']),1,0,'L');
	$pdf->Cell(45,6,$data['kode_keluar'],1,0,'L');
	$pdf->Cell(85,6,$data['nama_customer'],1,0,'L');
	$pdf->Cell(70,6,$data['nama_barang'],1,0,'L');
	$pdf->Cell(20,6,$data['satuan'],1,0,'L');
	$pdf->Cell(15,6,$data['jumlah_barang'],1,0,'R');
	$pdf->Cell(40,6,'Rp.'.number_format($data['harga_satuan']),1,0,'R');
	$pdf->Cell(40,6,'Rp.'.number_format($jumlahharga),1,0,'R');
	}
	$pdf->Ln(6);
	$pdf-> SetFont('Arial','B',12); // tipe font , bold , ukuran font
	$pdf->Cell(300);
	$pdf->Cell(40,6,'Total Harga Pokok',1,0,'L');
	$pdf->Cell(40,6,'Rp.'.number_format($total_harga_pokok),1,0,'R');
	

$pdf->Output();
