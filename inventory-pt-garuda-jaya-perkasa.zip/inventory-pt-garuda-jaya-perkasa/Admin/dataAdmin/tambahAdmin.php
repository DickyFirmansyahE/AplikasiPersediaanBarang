<?php
include "../koneksi.php";
// nomor otomatis
$query = "SELECT max(id_login) as maxKode FROM tblogin";
$hasil = mysqli_query($sambungin, $query);
$data = mysqli_fetch_array($hasil);
$id_login = $data['maxKode'];
$noUrut = (int) substr($id_login, 3, 3);
$noUrut++;
$char = "ADM";
$id_login = $char . sprintf("%03s", $noUrut);
echo $id_login;


if ($_SERVER['REQUEST_METHOD'] == "POST") {
  include "../koneksi.php";
  $id_login = $_POST['id_login'];
  $username = $_POST['username'];
  $password = $_POST['password'];
  $nama_admin = $_POST['nama_admin'];
  $no_hp = $_POST['no_hp'];

  $simpan = mysqli_query($sambungin, "INSERT INTO tblogin VALUES('$id_login','$username','$password','$nama_admin','$no_hp')");

  echo "
        <script>
        window.alert('Data Admin Berhasil Ditambahkan !!')
        </script>
      ";


  echo "
        <meta http-equiv='refresh' content = '0; url=?hal=dataAdmin'>
      ";
}

?>

<section id="main-content">
  <section class="wrapper">
    <!-- BASIC FORM ELELEMNTS -->
    <div class="row mt">
      <div class="col-lg-12">
        <div class="form-panel">
          <h4 style="font-size: 25px;"><i class="bi bi-person-badge"></i> Tambah Admin</h4>
          <hr class="mb">
          <form class="form-horizontal style-form" method="post" style="padding: 10px 100px; font-size: 18px;">
            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Kode Admin</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" style="font-size: 15px;" name="id_login" value="<?php echo $id_login ?>" readonly>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Username</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" style="font-size: 15px;" name="username" required>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Password</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" style="font-size: 15px;" name="password" required>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Nama Admin</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" style="font-size: 15px;" name="nama_admin" required="">
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">No Handphone</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" style="font-size: 15px;" name="no_hp" required="">
              </div>
            </div>

            <div class="form-group">
              <div class="col-sm-4">
                <button class="btn btn-primary" name="">Simpan</button>
                <a href="?hal=dataAdmin" class="btn btn-warning">Kembali</a>
              </div>
            </div>
          </form>
        </div>
      </div>
      <!-- col-lg-12-->
    </div>
  </section>
</section>