<?php
include "../koneksi.php";

$kode_barang = $_GET['kode_barang'];

if ($_SERVER['REQUEST_METHOD'] == "POST") {
  include "../koneksi.php";
  $kode_barang = $_POST['kode_barang'];
  $nama_barang = $_POST['nama_barang'];
  $satuan = $_POST['satuan'];
  $kode_kategori = $_POST['kode_kategori'];
  $harga_jual = $_POST['harga_jual'];
  $harga_beli = $_POST['harga_beli'];
  $stok = $_POST['stok'];

  $simpan = mysqli_query($sambungin, "UPDATE tbbarang SET nama_barang='$nama_barang', satuan='$satuan', kode_kategori='$kode_kategori', harga_jual='$harga_jual', harga_beli='$harga_beli', stok = '$stok' where kode_barang = '$kode_barang'");

  echo "
        <script>
        window.alert('Data Barang Berhasil Diubah !!')
        </script>
      ";


  echo "
        <meta http-equiv='refresh' content = '0; url=?hal=dataBarang'>
      ";
}

?>

<section id="main-content">
  <section class="wrapper">
    <!-- BASIC FORM ELELEMNTS -->
    <?php
    $query = mysqli_query($sambungin, "SELECT * FROM tbbarang where kode_barang = '$kode_barang'");
    while ($data = mysqli_fetch_array($query)) {

    ?>
      <div class="row mt">
        <div class="col-lg-12">
          <div class="form-panel">
            <h4 style="font-size: 25px;"><i class="bi bi-box-seam"></i> Ubah Barang</h4>
            <hr class="mb">
            <form class="form-horizontal style-form" method="post" style="padding: 10px 100px; font-size: 18px;">
              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Kode Barang</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="kode_barang" value="<?php echo $kode_barang ?>" readonly>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Nama Barang</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="nama_barang" value="<?php echo $data['nama_barang'] ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Satuan</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="satuan" value="<?php echo $data['satuan'] ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Kategori</label>
                <div class="col-sm-4">
                  <?php
                  include "../koneksi.php";
                  echo "<select class='form-control' name='kode_kategori' style='font-size: 15px;'>";
                  $tampil = mysqli_query($sambungin, "SELECT * FROM tbkategori");
                  while ($w = mysqli_fetch_array($tampil)) {
                    if ($data['kode_kategori'] == $w['kode_kategori']) {
                      echo "<option value=$w[kode_kategori] selected>$w[nama_kategori]</option>";
                    } else {
                      echo "<option value=$w[kode_kategori] >$w[nama_kategori]</option>";
                    }
                  }
                  echo "</select>";
                  ?>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Harga Satuan</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="harga_jual" value="<?php echo $data['harga_jual'] ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Harga Pokok</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="harga_beli" value="<?php echo $data['harga_beli'] ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Stok</label>
                <div class="col-sm-4">
                  <input type="number" class="form-control" style="font-size: 15px;" name="stok" value="<?php echo $data['stok'] ?>" readonly>
                </div>
              </div>


              <div class="form-group">
                <div class="col-sm-4">
                  <button class="btn btn-primary" name="">Simpan</button>
                  <a href="?hal=dataBarang" class="btn btn-warning">Kembali</a>
                </div>
              </div>



            </form>

          <?php
        }
          ?>
          </div>
        </div>
        <!-- col-lg-12-->
      </div>


  </section>
</section>