<?php
include "../cek.php";
header('location:beranda.php?hal=home');

?>