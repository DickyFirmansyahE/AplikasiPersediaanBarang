-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2023 at 06:30 AM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_persediaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbbarang`
--

CREATE TABLE `tbbarang` (
  `kode_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(40) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `kode_kategori` varchar(6) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `stok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbbarang`
--

INSERT INTO `tbbarang` (`kode_barang`, `nama_barang`, `satuan`, `kode_kategori`, `harga_jual`, `harga_beli`, `stok`) VALUES
('0414BR', '0414 / 11304 BR  P=6.00', 'BTG', 'KTG002', 126000, 122606, 50),
('0554BLK', '0554 / 4409  BLK 6.00', 'BTG', 'KTG001', 68000, 63568, 150),
('0554CA', '0554 / 4409  CA  6.00', 'BTG', 'KTG001', 58000, 53455, 30),
('09338-BR', '09338/22 BR P 6.0', 'BTG', 'KTG001', 50000, 45600, 34),
('11497MF', '11497 / 9102  MF P=6.00', 'BTG', 'KTG003', 148500, 144326, 90),
('11498MF', '11498 / 9103  MF P=6.00', 'BTG', 'KTG003', 118000, 113208, 45),
('120CA', '120 / 80 X 600 CA', 'LBR', 'KTG002', 582000, 578455, 29),
('1889BLK', '1889 / 7072 BLK P=6.00', 'BTG', 'KTG005', 70000, 66500, 45),
('1889BR', '1889 / 7072 BR  P=6.00', 'BTG', 'KTG005', 76500, 72000, 30),
('2001BR', '2001 / 4203 BR P=4.40', 'BTG', 'KTG004', 170000, 165200, 30),
('2002BLK', '2002 / 4202 BLK 4.4', 'BTG', 'KTG004', 169500, 164200, 65),
('4221CA', '4221 / H.KOTAK 1/2 X 1 CA', 'BTG', 'KTG006', 42500, 37200, 30),
('4223MF', '4223 / HOLLOW 11/2 X 11/2 MF 6', 'BTG', 'KTG006', 81000, 75600, 50),
('PS4', 'PLAT SHEET 0.2 X 605 X 1.4MM', 'LBR', 'KTG008', 15000, 12600, 76),
('SK5MF', 'SIKU 1/2 MF 6MTR', 'BTG', 'KTG007', 8000, 6300, 60);

-- --------------------------------------------------------

--
-- Table structure for table `tbcustomer`
--

CREATE TABLE `tbcustomer` (
  `kode_customer` varchar(6) NOT NULL,
  `nama_customer` varchar(30) NOT NULL,
  `contact_person` varchar(30) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `alamat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbcustomer`
--

INSERT INTO `tbcustomer` (`kode_customer`, `nama_customer`, `contact_person`, `no_telp`, `alamat`) VALUES
('CUS001', 'PT.ADICITRA BHIRAWA', '-', '021 44837033', 'KAWASAN INDUSTRI ESTATE WIRA'),
('CUS002', 'PT.ANEKA SURYA ALUMINIUM', '-', '0617367992', 'JL.THAMRIN NO.114'),
('CUS003', 'PT.INTI SUMBER ANUGRAH', '-', '55778071', 'JL.MAULANA HASANUDIN NO.149'),
('CUS004', 'PT.WITAKARYA PARAMITA', '-', '5302223', 'JL.SAKTI III KAV-EE NO.61 RT.008/009, KEMANGGISAN');

-- --------------------------------------------------------

--
-- Table structure for table `tbdetail_penerimaan`
--

CREATE TABLE `tbdetail_penerimaan` (
  `id` int(11) NOT NULL,
  `kode_terima` varchar(20) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `harga_pokok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbdetail_penerimaan`
--

INSERT INTO `tbdetail_penerimaan` (`id`, `kode_terima`, `kode_barang`, `jumlah_barang`, `harga_pokok`) VALUES
(3, 'INV202207090001', '1889BR', 100, 76500),
(4, 'INV202207090002', '4221CA', 20, 37200),
(5, 'INV202207090003', '2001BR', 10, 165200),
(6, 'INV202207090004', '0554CA', 25, 53455);

-- --------------------------------------------------------

--
-- Table structure for table `tbdetail_pengeluaran`
--

CREATE TABLE `tbdetail_pengeluaran` (
  `id` int(11) NOT NULL,
  `kode_keluar` varchar(20) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `harga_satuan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbdetail_pengeluaran`
--

INSERT INTO `tbdetail_pengeluaran` (`id`, `kode_keluar`, `kode_barang`, `jumlah_barang`, `harga_satuan`) VALUES
(2, 'FKT202207090001', '0554BLK', 5, 68000),
(3, 'FKT202207090001', '0414BR', 2, 126000),
(5, 'FKT202207090002', '120CA', 1, 582000),
(6, 'FKT202207090002', '1889BLK', 3, 70000),
(8, 'FKT202207090003', '0554BLK', 50, 69000),
(9, 'FKT202207090004', '2002BLK', 15, 169500),
(10, 'FKT202207090005', '11497MF', 20, 148500),
(11, 'FKT202207090006', '1889BR', 35, 76500),
(12, 'FKT202207090007', '0414BR', 3, 126000),
(13, 'FKT202207090007', 'SK5MF', 10, 8000),
(14, 'FKT202207090007', '4223MF', 2, 81000);

-- --------------------------------------------------------

--
-- Table structure for table `tbgabung_transaksi`
--

CREATE TABLE `tbgabung_transaksi` (
  `id` int(11) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `ket` varchar(20) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbgabung_transaksi`
--

INSERT INTO `tbgabung_transaksi` (`id`, `kode`, `tanggal`, `kode_barang`, `jumlah_barang`, `ket`, `waktu`) VALUES
(185, 'INV202207090001', '2022-07-09', '1889BR', 100, 'MASUK', '2022-07-09 14:05:25'),
(186, 'INV202207090001', '2022-07-09', '1889BR', 0, 'KELUAR', '2022-07-09 14:05:25'),
(187, 'INV202207090002', '2022-07-09', '4221CA', 20, 'MASUK', '2022-07-09 14:07:49'),
(188, 'INV202207090002', '2022-07-09', '4221CA', 0, 'KELUAR', '2022-07-09 14:07:49'),
(189, 'INV202207090003', '2022-07-09', '2001BR', 10, 'MASUK', '2022-07-09 14:08:46'),
(190, 'INV202207090003', '2022-07-09', '2001BR', 0, 'KELUAR', '2022-07-09 14:08:46'),
(191, 'INV202207090004', '2022-07-09', '0554CA', 25, 'MASUK', '2022-07-09 14:10:40'),
(192, 'INV202207090004', '2022-07-09', '0554CA', 0, 'KELUAR', '2022-07-09 14:10:40'),
(193, 'FKT202207090001', '2022-07-09', '0554BL', 5, 'KELUAR', '2022-07-09 14:28:17'),
(194, 'FKT202207090001', '2022-07-09', '0554BL', 0, 'MASUK', '2022-07-09 14:28:17'),
(195, 'FKT202207090001', '2022-07-09', '0554BLK', 5, 'KELUAR', '2022-07-09 14:32:44'),
(196, 'FKT202207090001', '2022-07-09', '0414BR', 2, 'KELUAR', '2022-07-09 14:32:44'),
(198, 'FKT202207090001', '2022-07-09', '0554BLK', 0, 'MASUK', '2022-07-09 14:32:44'),
(199, 'FKT202207090001', '2022-07-09', '0414BR', 0, 'MASUK', '2022-07-09 14:32:44'),
(201, 'FKT202207090002', '2022-07-09', '120CA', 1, 'KELUAR', '2022-07-09 14:35:01'),
(202, 'FKT202207090002', '2022-07-09', '1889BLK', 3, 'KELUAR', '2022-07-09 14:35:01'),
(204, 'FKT202207090002', '2022-07-09', '120CA', 0, 'MASUK', '2022-07-09 14:35:01'),
(205, 'FKT202207090002', '2022-07-09', '1889BLK', 0, 'MASUK', '2022-07-09 14:35:01'),
(207, 'FKT202207090003', '2022-07-09', '0554BLK', 50, 'KELUAR', '2022-07-09 14:36:08'),
(208, 'FKT202207090003', '2022-07-09', '0554BLK', 0, 'MASUK', '2022-07-09 14:36:08'),
(209, 'FKT202207090004', '2022-07-09', '2002BLK', 15, 'KELUAR', '2022-07-09 14:37:08'),
(210, 'FKT202207090004', '2022-07-09', '2002BLK', 0, 'MASUK', '2022-07-09 14:37:08'),
(211, 'FKT202207090005', '2022-07-09', '11497MF', 20, 'KELUAR', '2022-07-09 14:38:20'),
(212, 'FKT202207090005', '2022-07-09', '11497MF', 0, 'MASUK', '2022-07-09 14:38:20'),
(213, 'FKT202207090006', '2022-07-09', '1889BR', 35, 'KELUAR', '2022-07-09 14:39:18'),
(214, 'FKT202207090006', '2022-07-09', '1889BR', 0, 'MASUK', '2022-07-09 14:39:18'),
(215, 'FKT202207090007', '2022-07-09', '0414BR', 3, 'KELUAR', '2022-07-09 14:41:10'),
(216, 'FKT202207090007', '2022-07-09', 'SK5MF', 10, 'KELUAR', '2022-07-09 14:41:10'),
(217, 'FKT202207090007', '2022-07-09', '4223MF', 2, 'KELUAR', '2022-07-09 14:41:10'),
(218, 'FKT202207090007', '2022-07-09', '0414BR', 0, 'MASUK', '2022-07-09 14:41:10'),
(219, 'FKT202207090007', '2022-07-09', 'SK5MF', 0, 'MASUK', '2022-07-09 14:41:10'),
(220, 'FKT202207090007', '2022-07-09', '4223MF', 0, 'MASUK', '2022-07-09 14:41:10'),
(221, 'FKT202207100001', '2022-07-10', '09338-BR', 12, 'KELUAR', '2022-07-10 07:29:20'),
(222, 'FKT202207100001', '2022-07-10', '09338-BR', 0, 'MASUK', '2022-07-10 07:29:20');

-- --------------------------------------------------------

--
-- Table structure for table `tbkategori`
--

CREATE TABLE `tbkategori` (
  `kode_kategori` varchar(6) NOT NULL,
  `nama_kategori` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbkategori`
--

INSERT INTO `tbkategori` (`kode_kategori`, `nama_kategori`) VALUES
('KTG001', 'KUSEN 4X1 3/4 1MM'),
('KTG002', 'KUSEN 3X1 1/2 1 MM'),
('KTG003', 'SLIDING DOOR'),
('KTG004', 'SWING DOOR'),
('KTG005', 'CATENWOL'),
('KTG006', 'HOLLOW'),
('KTG007', 'SIKU'),
('KTG008', 'PLAT');

-- --------------------------------------------------------

--
-- Table structure for table `tblogin`
--

CREATE TABLE `tblogin` (
  `id_login` varchar(6) NOT NULL,
  `username` varchar(12) NOT NULL,
  `password` varchar(12) NOT NULL,
  `nama_admin` varchar(50) NOT NULL,
  `no_hp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblogin`
--

INSERT INTO `tblogin` (`id_login`, `username`, `password`, `nama_admin`, `no_hp`) VALUES
('ADM001', 'Dicky', 'dicky191', 'Dicky Firmansyah', '085814967966'),
('ADM002', 'Naufal', 'naufal123', 'Naufal', '081316879938'),
('ADM003', 'Akmal', 'akmal101', 'Akmal Raharjo', '082845339878');

-- --------------------------------------------------------

--
-- Table structure for table `tbpenerimaan`
--

CREATE TABLE `tbpenerimaan` (
  `kode_terima` varchar(20) NOT NULL,
  `tanggal_terima` date NOT NULL,
  `jumlah_item` int(11) NOT NULL,
  `kode_supplier` varchar(6) NOT NULL,
  `id_login` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbpenerimaan`
--

INSERT INTO `tbpenerimaan` (`kode_terima`, `tanggal_terima`, `jumlah_item`, `kode_supplier`, `id_login`) VALUES
('INV202207090001', '2022-07-09', 1, 'SUP001', 'ADM001'),
('INV202207090002', '2022-07-09', 1, 'SUP002', 'ADM001'),
('INV202207090003', '2022-07-09', 1, 'SUP003', 'ADM001'),
('INV202207090004', '2022-07-09', 1, 'SUP004', 'ADM001');

-- --------------------------------------------------------

--
-- Table structure for table `tbpengeluaran`
--

CREATE TABLE `tbpengeluaran` (
  `kode_keluar` varchar(20) NOT NULL,
  `tanggal_keluar` date NOT NULL,
  `jumlah_item` int(11) NOT NULL,
  `kode_customer` varchar(6) NOT NULL,
  `id_login` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbpengeluaran`
--

INSERT INTO `tbpengeluaran` (`kode_keluar`, `tanggal_keluar`, `jumlah_item`, `kode_customer`, `id_login`) VALUES
('FKT202207090001', '2022-07-09', 2, 'CUS001', 'ADM001'),
('FKT202207090002', '2022-07-09', 2, 'CUS002', 'ADM001'),
('FKT202207090003', '2022-07-09', 1, 'CUS003', 'ADM001'),
('FKT202207090004', '2022-07-09', 1, 'CUS003', 'ADM001'),
('FKT202207090005', '2022-07-09', 1, 'CUS002', 'ADM001'),
('FKT202207090006', '2022-07-09', 1, 'CUS004', 'ADM001'),
('FKT202207090007', '2022-07-09', 3, 'CUS004', 'ADM001');

-- --------------------------------------------------------

--
-- Table structure for table `tbsementara`
--

CREATE TABLE `tbsementara` (
  `id` int(11) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbsupplier`
--

CREATE TABLE `tbsupplier` (
  `kode_supplier` varchar(6) NOT NULL,
  `nama_supplier` varchar(30) NOT NULL,
  `contact_person` varchar(30) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `alamat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbsupplier`
--

INSERT INTO `tbsupplier` (`kode_supplier`, `nama_supplier`, `contact_person`, `no_telp`, `alamat`) VALUES
('SUP001', 'PT.ALEXINDO', 'Eko Setiawan', '0218843460', 'BEKASI'),
('SUP002', 'PT. ALUMEX PERKASAJAYA', '-', '55655109', 'KP.DUMPIT RT/RW 003/005'),
('SUP003', 'PT.ALCONA UTAMA NUSA', '-', '0218621 0126', 'JAKARTA'),
('SUP004', 'PT.ALUPRIMA PACIFIC INDUSTRIES', 'Robie', '5306247', 'PLAZA KEBON JERUK BLOK.E NO. 3'),
('SUP005', 'PT SEMPURNA ALUMICO', 'Hairul', '66696180', 'TAMAN KOTA BLOK B.I/23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbbarang`
--
ALTER TABLE `tbbarang`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indexes for table `tbcustomer`
--
ALTER TABLE `tbcustomer`
  ADD PRIMARY KEY (`kode_customer`);

--
-- Indexes for table `tbdetail_penerimaan`
--
ALTER TABLE `tbdetail_penerimaan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbdetail_pengeluaran`
--
ALTER TABLE `tbdetail_pengeluaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbgabung_transaksi`
--
ALTER TABLE `tbgabung_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbkategori`
--
ALTER TABLE `tbkategori`
  ADD PRIMARY KEY (`kode_kategori`);

--
-- Indexes for table `tblogin`
--
ALTER TABLE `tblogin`
  ADD PRIMARY KEY (`id_login`);

--
-- Indexes for table `tbpenerimaan`
--
ALTER TABLE `tbpenerimaan`
  ADD PRIMARY KEY (`kode_terima`);

--
-- Indexes for table `tbpengeluaran`
--
ALTER TABLE `tbpengeluaran`
  ADD PRIMARY KEY (`kode_keluar`);

--
-- Indexes for table `tbsementara`
--
ALTER TABLE `tbsementara`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbsupplier`
--
ALTER TABLE `tbsupplier`
  ADD PRIMARY KEY (`kode_supplier`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbdetail_penerimaan`
--
ALTER TABLE `tbdetail_penerimaan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbdetail_pengeluaran`
--
ALTER TABLE `tbdetail_pengeluaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tbgabung_transaksi`
--
ALTER TABLE `tbgabung_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=223;
--
-- AUTO_INCREMENT for table `tbsementara`
--
ALTER TABLE `tbsementara`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
