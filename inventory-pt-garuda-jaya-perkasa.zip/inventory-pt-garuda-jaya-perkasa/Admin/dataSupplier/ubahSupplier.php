<?php
include "../koneksi.php";

$kode_supplier = $_GET['kode_supplier'];




if ($_SERVER['REQUEST_METHOD'] == "POST") {
  include "../koneksi.php";
  $kode_supplier = $_POST['kode_supplier'];
  $nama_supplier = $_POST['nama_supplier'];
  $contact_person = $_POST['contact_person'];
  $no_telp = $_POST['no_telp'];
  $alamat = $_POST['alamat'];


  $simpan = mysqli_query($sambungin, "UPDATE tbsupplier SET nama_supplier='$nama_supplier', contact_person='$contact_person', no_telp = '$no_telp', alamat='$alamat' where kode_supplier = '$kode_supplier'");

  echo "
        <script>
        window.alert('Data Supplier Berhasil Diubah !!')
        </script>
      ";


  echo "
        <meta http-equiv='refresh' content = '0; url=?hal=dataSupplier'>
      ";
}

?>







<section id="main-content">
  <section class="wrapper">
    <!-- BASIC FORM ELELEMNTS -->
    <?php
    $query = mysqli_query($sambungin, "SELECT * FROM tbsupplier where kode_supplier = '$kode_supplier'");
    while ($data = mysqli_fetch_array($query)) {

    ?>
      <div class="row mt">
        <div class="col-lg-12">
          <div class="form-panel">
            <h4 style="font-size: 25px;"><i class="bi bi-building"></i>Ubah Supplier</h4>
            <hr class="mb">
            <form class="form-horizontal style-form" method="post" style="padding: 10px 100px; font-size: 18px;">
              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Kode Supplier</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="kode_supplier" value="<?php echo $kode_supplier ?>" readonly>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Nama Supplier</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="nama_supplier" value="<?php echo $data['nama_supplier'] ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Contact Person</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="contact_person" value="<?php echo $data['contact_person'] ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">No Telepon</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="no_telp" value="<?php echo $data['no_telp'] ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Alamat</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="alamat" value="<?php echo $data['alamat'] ?>">
                </div>
              </div>

              <div class="form-group">
                <div class="col-sm-4">
                  <button class="btn btn-primary" name="">Simpan</button>
                  <a href="?hal=dataSupplier" class="btn btn-warning">Kembali</a>
                </div>
              </div>
            </form>

          <?php
        }
          ?>
          </div>
        </div>
        <!-- col-lg-12-->
      </div>
  </section>
</section>