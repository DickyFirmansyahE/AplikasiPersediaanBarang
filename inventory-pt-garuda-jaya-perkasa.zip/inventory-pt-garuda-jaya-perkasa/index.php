<?php
include "koneksi.php";

if(isset($_POST['login'])){
  $username = $_POST['username'];
  $password = $_POST['password'];

  $login = mysqli_query($sambungin,"SELECT * FROM tblogin where username = '$username' and password = '$password'");
  $ketemu = mysqli_num_rows($login);
  $r = mysqli_fetch_array($login);

  if($ketemu > 0){
		$_SESSION['log'] = 'True';
    $_SESSION['id_login']	=	$r['id_login'];
		$_SESSION['username']	=	$r['username'];
		$_SESSION['nama_admin']	=	$r['nama_admin'];
		$_SESSION['no_hp']	=	$r['no_hp'];
    echo "
        <script>
        alert('Anda Berhasil Login, Selamat datang $_SESSION[username]');
        window.location = 'admin/index.php'
        </script>
    ";
    }else{
  
        echo "
        <script>
        alert('Username atau Password Salah');
        window.location = 'index.php'
        </script>
    ";
  
  
    };
};

if(!isset($_SESSION['log'])){

}else{
  echo "
        <script>
        alert('Anda telah login sebagai $_SESSION[username]');
        window.location = 'admin/index.php'
        </script>
        ";
};
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Login - Inventory</title>

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">

  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  
  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body>
  <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
  <div id="login-page">
    <div class="container" style="padding: 60px 0px;">
      <form class="form-login" method="post" style="max-width: 500px;">
        <h2 class="form-login-heading" style="font-size: 30px;">
        <p>INVENTORY</p>
        <p>PT. GARUDA JAYA PERKASA</p>
      </h2>
        <div class="login-wrap">
          <input  style="font-size: 17px;" type="text" class="form-control" name="username" placeholder="Username" autofocus>
          <br>
          <input style="font-size: 17px;" type="password" class="form-control" name="password" placeholder="Password">
          <br>
          <button style="font-size: 17px;" class="btn btn-theme btn-block" href="index.html" type="submit" name="login"><i class="bi bi-box-arrow-in-right"></i> MASUK</button>
          <hr>
          <h2 class="text-center" style="font-size: 15px;">Ada Masalah? Silahkan Hubungi Admin</h2>
          <h2 class="text-center" style="font-size: 15px;"><i class="fa fa-copyright"></i> PT. GARUDA JAYA PERKASA 2022</h2>
        <!-- Modal -->
        
        <!-- modal -->
      </form>
    </div>
  </div>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <!--BACKSTRETCH-->
  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
  <script type="text/javascript" src="lib/jquery.backstretch.min.js"></script>
  <script>
    $.backstretch("img/warehouses.webp", {
      speed: 500
    });
  </script>
</body>

</html>
