<?php
include "../koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
  include "../koneksi.php";
  $kode_barang = $_POST['kode_barang'];
  $nama_barang = $_POST['nama_barang'];
  $satuan = $_POST['satuan'];
  $kode_kategori = $_POST['kode_kategori'];
  $harga_jual = $_POST['harga_jual'];
  $harga_beli = $_POST['harga_beli'];
  $stok = $_POST['stok'];

  $simpan = mysqli_query($sambungin, "INSERT INTO tbbarang VALUES('$kode_barang','$nama_barang','$satuan','$kode_kategori','$harga_jual','$harga_beli','$stok')");

  echo "
        <script>
        window.alert('Data Barang Berhasil Ditambahkan !!')
        </script>
      ";


  echo "
        <meta http-equiv='refresh' content = '0; url=?hal=dataBarang'>
      ";
}

?>







<section id="main-content">
  <section class="wrapper">
    <!-- BASIC FORM ELELEMNTS -->
    <div class="row mt">
      <div class="col-lg-12">
        <div class="form-panel">
          <h4 style="font-size: 25px;"><i class="bi bi-box-seam"></i> Tambah Barang</h4>
          <hr class="mb">
          <form class="form-horizontal style-form" method="post" style="padding: 10px 100px; font-size: 18px;">
            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;"> Kode Barang</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" name="kode_barang" required="" style="font-size: 15px;">
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;"> Nama Barang</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" name="nama_barang" required="" style="font-size: 15px;">
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;"> Satuan</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" name="satuan" required="" style="font-size: 15px;">
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;"> Kategori</label>
              <div class="col-sm-4">
                <?php
                include "../koneksi.php";
                echo "<select class='form-control' name='kode_kategori' style='font-size: 15px;'>";
                $tampil = mysqli_query($sambungin, "SELECT * FROM tbkategori");
                while ($data = mysqli_fetch_array($tampil)) {
                  echo "<option value=$data[kode_kategori] >$data[nama_kategori]</option>";
                }
                echo "</select>";
                ?>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;"> Harga Jual</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" name="harga_jual" required="" style="font-size: 15px;">
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;"> Harga Beli</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" name="harga_beli" required="" style="font-size: 15px;">
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;"> Stok</label>
              <div class="col-sm-4">
                <input type="number" class="form-control" name="stok" required="" style="font-size: 15px;">
              </div>
            </div>

            <div class="form-group">
              <div class="col-sm-4">
                <button class="btn btn-primary" name="">Simpan</button>
                <a href="?hal=dataBarang" class="btn btn-warning">Kembali</a>
              </div>
            </div>
          </form>
        </div>
      </div>
      <!-- col-lg-12-->
    </div>
  </section>
</section>