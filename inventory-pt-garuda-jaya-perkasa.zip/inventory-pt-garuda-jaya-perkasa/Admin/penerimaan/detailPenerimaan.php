<?php
include "../koneksi.php";
$kode_terima = $_GET['kode_terima'];

$dataAtas = mysqli_query($sambungin, "SELECT * FROM tbpenerimaan left join tbsupplier on tbpenerimaan.kode_supplier = tbsupplier.kode_supplier where kode_terima = '$kode_terima'");
$x = mysqli_fetch_array($dataAtas);
?>


<section id="main-content">
	<section class="wrapper">
		<div class="col-lg-12 mt">
			<div class="row content-panel">
				<div class="col-lg-10 col-lg-offset-1">
					<div class="pull-left">
						<h2>Detail Pembelian Barang</h2>
					</div>
					<div class="clearfix"></div>
					<div class="row">
						<div class="col-md-5" style="font-size: 15px;">

							<div>
								<div class="pull-left">NOMOR INVOICE :</div>
								<div class="pull-right"><?php echo $x['kode_terima'] ?> </div>
								<div class="clearfix"></div>
							</div>
							<div>
								<div class="pull-left">TANGGAL :</div>
								<div class="pull-right"><?php echo $x['tanggal_terima'] ?></div>
								<div class="clearfix"></div>
							</div>
							<div>
								<div class="pull-left">SUPPLIER :</div>
								<div class="pull-right"><?php echo $x['nama_supplier'] ?> </div>
								<div class="clearfix"></div>
							</div>
							<div>
								<div class="pull-left">JUMLAH ITEM :</div>
								<div class="pull-right"><?php echo $x['jumlah_item'] ?> </div>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>
					<br>
					<table class="table" style="font-size: 15px;">
						<thead>
							<?php
							include "../koneksi.php";
							$dataBawah = mysqli_query($sambungin, "SELECT * FROM tbpenerimaan left join tbdetail_penerimaan on tbpenerimaan.kode_terima = tbdetail_penerimaan.kode_terima left join tbbarang on tbdetail_penerimaan.kode_barang = tbbarang.kode_barang where tbpenerimaan.kode_terima = '$kode_terima'");
							?>
							<tr>
								<th style="width: 50px">No</th>
								<th style="width: 150px">KODE BARANG</th>
								<th class="text-left" style="width: 450px">NAMA BARANG</th>
								<th style="width: 150px">SATUAN</th>
								<th style="width: 50px">QTY</th>
								<th style="width: 50px"></th>
								<th style="width: 150px">HARGA POKOK</th>
								<th style="width: 50px"></th>
								<th style="width: 150px">JUMLAH</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$no = 1;
							$total_harga_pokok = 0;
							while ($data = mysqli_fetch_array($dataBawah)) {
								$jumlahharga = $data['jumlah_barang'] * $data['harga_pokok'];
								$total_harga_pokok += $jumlahharga;
							?>
								<tr>
									<td><?php echo $no++ ?></td>
									<td><?php echo $data['kode_barang'] ?></td>
									<td><?php echo $data['nama_barang'] ?></td>
									<td><?php echo $data['satuan'] ?></td>
									<td><?php echo $data['jumlah_barang'] ?></td>
									<td>X</td>
									<td>Rp.<?php echo number_format($data['harga_pokok']) ?></td>
									<td>=</td>
									<td>Rp.<?php echo number_format($jumlahharga) ?></td>
								</tr>

							<?php
							}
							?>
							<tr>
								<th>TOTAL</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td>Rp.<?php echo number_format($total_harga_pokok) ?></td>
							</tr>
						</tbody>

					</table>
					<div class="form-group">
						<div class="col-sm-4">
							<a href="beranda.php?hal=dataPenerimaan" class="btn btn-info">Kembali</a>
						</div>

					</div>
				</div>

			</div>

		</div>
	</section>
</section>