 <?php
  include "../koneksi.php";
  include "../cek.php";

  $pembelian = mysqli_query($sambungin, "SELECT nama_supplier , SUM(jumlah_barang) As total from tbpenerimaan left join tbdetail_penerimaan on tbpenerimaan.kode_terima = tbdetail_penerimaan.kode_terima left join tbsupplier on tbpenerimaan.kode_supplier = tbsupplier.kode_supplier Group By nama_supplier")
  ?>

 <section id="main-content">
   <section class="wrapper">
     <br>
     <div class="row">
       <div class="col-lg-9 main-chart">
         <!--CUSTOM CHART START -->
         <div class="border-head">
           <h3 class="text-center">GRAFIK PEMBELIAN BARANG</h3>
         </div>
         <div class="custom-bar-chart">
           <ul class="y-axis">

           </ul>

           <?php
            while ($data = mysqli_fetch_array($pembelian)) {
            ?>
             <div class="bar">
               <div class="title" style="width: 90px; margin-left: -12%;"><?php echo $data['nama_supplier'] ?></div>
               <div class="value tooltips" data-original-title="<?php echo $data['total'] ?>" data-toggle="tooltip" data-placement="top"><?php echo $data['total'] ?></div>
             </div>
           <?php
            }
            ?>

         </div>
         <br>
         <br>
         <div class="border-head">
           <h3 class="text-center">GRAFIK PENJUALAN BARANG</h3>
         </div>
         <div class="custom-bar-chart">
           <ul class="y-axis">

           </ul>

           <?php
            $penjualan = mysqli_query($sambungin, "SELECT nama_customer , SUM(jumlah_barang) As total from tbpengeluaran left join tbdetail_pengeluaran on tbpengeluaran.kode_keluar = tbdetail_pengeluaran.kode_keluar left join tbcustomer on tbpengeluaran.kode_customer = tbcustomer.kode_customer Group By nama_customer");
            while ($data1 = mysqli_fetch_array($penjualan)) {
            ?>
             <div class="bar">
               <div class="title" style="width: 90px; margin-left: -12%;"><?php echo $data1['nama_customer'] ?></div>
               <div class="value tooltips" data-original-title="<?php echo $data1['total'] ?>" data-toggle="tooltip" data-placement="top"><?php echo $data1['total'] ?></div>
             </div>
           <?php
            }
            ?>
         </div>
       </div>

       <!-- /col-lg-9 END SECTION MIDDLE -->
       <!-- **********************************************************************************************************************************************************
              RIGHT SIDEBAR CONTENT
              *********************************************************************************************************************************************************** -->
       <br>
       <!--/ col-md-4 -->
       <div class="col-lg-3">
         <div class="green-panel pn">
           <div class="green-header">
             <h5 style="font-size: 20px;">BARANG TERJUAL</h5> 
           </div>
           <i class="bi bi-cart" style="font-size: 90px;"></i>
           <div class="row">
             <div class="col-sm-6 col-xs-6 goleft">
               <p style="font-size: 20px; padding: 5% 20%">TOTAL :</p>
             </div>
             <div class="col-sm-6 col-xs-6">
               <?php
                $penjualan = mysqli_query($sambungin, "SELECT SUM(jumlah_barang) As total from tbpengeluaran left join tbdetail_pengeluaran on tbpengeluaran.kode_keluar = tbdetail_pengeluaran.kode_keluar left join tbcustomer on tbpengeluaran.kode_customer = tbcustomer.kode_customer");
                while ($data1 = mysqli_fetch_array($penjualan)) {
                ?>
                 <h2 style="color:aliceblue; padding: 0% 60%; margin-top: 10px"><?php echo $data1['total'] ?></h2>
               <?php
                }
                ?>
             </div>
           </div>
         </div>
         <!-- /grey-panel -->
       </div>
       
       <!-- /col-md-4 -->
       <div class="col-lg-3">
       <br>
         <!-- REVENUE PANEL -->
         <div class="green-panel pn">
           <div class="green-header">
             <h5 style="font-size: 20px;">PENDAPATAN</h5>
           </div>
           <i class="bi bi-graph-up-arrow" style="font-size: 90px;"></i>
           <div class="chart mt">
             <div class="sparkline" data-type="line" data-resize="false" data-height="75" data-width="90%" data-line-width="1" data-line-color="#fff" data-spot-color="#fff" data-fill-color="" data-highlight-line-color="#fff" data-spot-radius="4" ></div>
           </div>
           <?php
           $total_harga_pokok = 0;
           $query = mysqli_query($sambungin,"SELECT  * FROM tbdetail_penerimaan left join tbpenerimaan on tbdetail_penerimaan.kode_terima = tbpenerimaan.kode_terima left join tbbarang on tbdetail_penerimaan.kode_barang = tbbarang.kode_barang left join tbsupplier on tbpenerimaan.kode_supplier = tbsupplier.kode_supplier");
           while ($data = mysqli_fetch_array($query)){
             $jumlahharga = $data['jumlah_barang'] * $data['harga_pokok'];
             $total_harga_pokok += $jumlahharga;
            }
           ?>
           <?php
           $total_harga_pokok2 = 0;
           $query2 = mysqli_query($sambungin,"SELECT  * FROM tbdetail_pengeluaran left join tbpengeluaran on tbdetail_pengeluaran.kode_keluar = tbpengeluaran.kode_keluar left join tbbarang on tbdetail_pengeluaran.kode_barang = tbbarang.kode_barang left join tbcustomer on tbpengeluaran.kode_customer = tbcustomer.kode_customer");
           while ($data2 = mysqli_fetch_array($query2)){
             $jumlahharga2 = $data2['jumlah_barang'] * $data2['harga_satuan'];
             $total_harga_pokok2 += $jumlahharga2;
            }
           ?>
           <?php 
           $laba = $total_harga_pokok2 - $total_harga_pokok;
           ?>
           <h2 style="color:aliceblue; margin-top: -90px"><b>Rp.<?php echo number_format($laba)?></h2>
         </div>
       </div>
       <!-- /col-md-4 -->
       
       <!-- /col-lg-3 -->
     </div>
     <!-- /row -->
   </section>
 </section>
 <!--main content end-->