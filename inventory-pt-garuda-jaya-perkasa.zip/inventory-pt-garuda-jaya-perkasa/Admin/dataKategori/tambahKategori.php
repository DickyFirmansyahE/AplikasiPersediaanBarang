<?php

if ($_SERVER['REQUEST_METHOD'] == "POST") {
  include "../koneksi.php";
  $kode_kategori = $_POST['kode_kategori'];
  $nama_kategori = $_POST['nama_kategori'];

  $simpan = mysqli_query($sambungin, "INSERT INTO tbkategori VALUES('$kode_kategori','$nama_kategori')");

  echo "
        <script>
        window.alert('Data Kategori Berhasil Ditambahkan !!')
        </script>
      ";


  echo "
        <meta http-equiv='refresh' content = '0; url=?hal=dataKategori'>
      ";
}

?>

<section id="main-content">
  <section class="wrapper">
    <!-- BASIC FORM ELELEMNTS -->
    <div class="row mt">
      <div class="col-lg-12">
        <div class="form-panel">
          <h4 style="font-size: 25px;"><i class="bi bi-tags"></i> Tambah Kategori</h4>
          <hr class="mb">
          <form class="form-horizontal style-form" method="post" style="padding: 10px 100px; font-size: 18px;">

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Kode Kategori</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" name="kode_kategori" maxlength="6" style="font-size: 15px;">
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Nama Kategori</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" name="nama_kategori" style="font-size: 15px;">
              </div>
            </div>

            <div class="form-group">
              <div class="col-sm-4">
                <button class="btn btn-primary" name="">Simpan</button>
                <a href="?hal=dataKategori" class="btn btn-warning">Kembali</a>
              </div>
            </div>
          </form>
        </div>
      </div>
      <!-- col-lg-12-->
    </div>
  </section>
</section>