<section id="main-content">
  <section class="wrapper">

    <div class="row mt">
      <div class="col-md-12">
        <div class="content-panel">
          <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" style="width: 98%; margin-left: 1%; font-size: 15px;">
            <h4 style="font-size: 25px;"><i class="bi bi-person-badge"></i> Data Admin</h4>
            <hr>
            <div class="text-right" style="margin-right: 25px;">
              <a href="?hal=tambahAdmin" class="btn btn-primary" style="font-size: 16px;"> Tambah Admin </a>
            </div>
            <div class="text-center">
              <form class="d-flex" method="post">
                <input type="search" name="cari" placeholder="Search" aria-label="Search" size="30" style="font-size: 15px;">
                <button class="btn btn-primary" name="sumbit_search" type="submit" style="padding: 3px 15px; font-size: 16px;">Search</button>
              </form>
            </div>
            <br>
            <thead>
              <?php
              include "../koneksi.php";


              ?>
              <tr>
                <th style="width: 50px"> NO</th>
                <th> Kode Admin</th>
                <th class="hidden-phone"> Nama Admin</th>
                <th class="hidden-phone"> No Handphone</th>

                <th>Aksi</th>
              </tr>
            </thead>

            <tbody>
              <?php
              $page = (isset($_GET['page'])) ? (int) $_GET['page'] : 1;

              // Jumlah data per halaman
              $limit = 10;

              $limitStart = ($page - 1) * $limit;

              $query = mysqli_query($sambungin, "SELECT * FROM tblogin LIMIT " . $limitStart . "," . $limit);

              $no = $limitStart + 1;

              if (isset($_POST['sumbit_search'])) {
                $cari = $_POST['cari'];
                $query = mysqli_query($sambungin, "SELECT * FROM tblogin WHERE id_login LIKE '%$cari%' OR nama_admin LIKE '%$cari%'");
              }

              while ($data = mysqli_fetch_array($query)) {
              ?>
                <tr>
                  <td><?php echo $no++ ?></td>
                  <td class="hidden-phone"><?php echo $data['id_login'] ?></td>
                  <td class="hidden-phone"><?php echo $data['nama_admin'] ?></td>
                  <td class="hidden-phone"><?php echo $data['no_hp'] ?></td>

                  <td>
                    <a href="beranda.php?hal=ubahAdmin&id_login=<?php echo $data['id_login'] ?>" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                    <a href="dataAdmin/hapusAdmin.php?id_login=<?php echo $data['id_login'] ?>" class="btn btn-danger btn-xs" onclick="return confirm('Yakin Akan dihapus?')"><i class="fa fa-trash-o "></i></a>
                  </td>
                </tr>
              <?php
              }
              ?>
            </tbody>
          </table>

          <div class="text-center">
            <ul class="pagination">
              <?php
              // Jika page = 1, maka LinkPrev disable
              if ($page == 1) {
              ?>
                <!-- link Previous Page disable -->
                <li class="disabled"><a href="#">Previous</a></li>
              <?php
              } else {
                $LinkPrev = ($page > 1) ? $page - 1 : 1;
              ?>
                <!-- link Previous Page -->
                <li><a href="beranda.php?hal=dataAdmin&page=<?php echo $LinkPrev; ?>">Previous</a></li>
              <?php
              }
              ?>

              <?php
              $query = mysqli_query($sambungin, "SELECT * FROM tblogin");

              //Hitung semua jumlah data yang berada pada tabel Sisawa
              $JumlahData = mysqli_num_rows($query);

              // Hitung jumlah halaman yang tersedia
              $jumlahPage = ceil($JumlahData / $limit);

              // Jumlah link number 
              $jumlahNumber = 10;

              // Untuk awal link number
              $startNumber = ($page > $jumlahNumber) ? $page - $jumlahNumber : 1;

              // Untuk akhir link number
              $endNumber = ($page < ($jumlahPage - $jumlahNumber)) ? $page + $jumlahNumber : $jumlahPage;

              for ($i = $startNumber; $i <= $endNumber; $i++) {
                $linkActive = ($page == $i) ? ' class="active"' : '';
              ?>
                <li<?php echo $linkActive; ?>><a href="beranda.php?hal=dataAdmin&page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                <?php
              }
                ?>

                <!-- link Next Page -->
                <?php
                if ($page == $jumlahPage) {
                ?>
                  <li class="disabled"><a href="#">Next</a></li>
                <?php
                } else {
                  $linkNext = ($page < $jumlahPage) ? $page + 1 : $jumlahPage;
                ?>
                  <li><a href="beranda.php?hal=dataAdmin&page=<?php echo $linkNext; ?>">Next</a></li>
                <?php
                }
                ?>
            </ul>
          </div>

        </div>
        <!-- /content-panel -->
      </div>
      <!-- /col-md-12 -->
    </div>
  </section>
</section>