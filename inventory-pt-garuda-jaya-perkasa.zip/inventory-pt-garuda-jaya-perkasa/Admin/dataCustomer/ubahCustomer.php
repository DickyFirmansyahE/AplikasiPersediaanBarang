<?php
include "../koneksi.php";

$kode_customer = $_GET['kode_customer'];




if ($_SERVER['REQUEST_METHOD'] == "POST") {
  include "../koneksi.php";
  $kode_customer = $_POST['kode_customer'];
  $nama_customer = $_POST['nama_customer'];
  $contact_person = $_POST['contact_person'];
  $no_telp = $_POST['no_telp'];
  $alamat = $_POST['alamat'];


  $simpan = mysqli_query($sambungin, "UPDATE tbcustomer SET nama_customer='$nama_customer', contact_person='$contact_person', no_telp = '$no_telp', alamat='$alamat' where kode_customer = '$kode_customer'");

  echo "
        <script>
        window.alert('Data Customer Berhasil Diubah !!')
        </script>
      ";


  echo "
        <meta http-equiv='refresh' content = '0; url=?hal=dataCustomer'>
      ";
}

?>







<section id="main-content">
  <section class="wrapper">
    <!-- BASIC FORM ELELEMNTS -->
    <?php
    $query = mysqli_query($sambungin, "SELECT * FROM tbcustomer where kode_customer = '$kode_customer'");
    while ($data = mysqli_fetch_array($query)) {

    ?>
      <div class="row mt">
        <div class="col-lg-12">
          <div class="form-panel">
            <h4 style="font-size: 25px;"><i class="bi bi-building"></i> Ubah Customer</h4>
            <hr class="mb">
            <form class="form-horizontal style-form" method="post" style="padding: 10px 100px; font-size: 18px;">
              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Kode Customer</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="kode_customer" value="<?php echo $kode_customer ?>" readonly>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Nama Customer</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="nama_customer" value="<?php echo $data['nama_customer'] ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Contact Person</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="contact_person" value="<?php echo $data['contact_person'] ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">No Telepon</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="no_telp" value="<?php echo $data['no_telp'] ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label" style="font-weight:bold;">Alamat</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" style="font-size: 15px;" name="alamat" value="<?php echo $data['alamat'] ?>">
                </div>
              </div>

              <div class="form-group">
                <div class="col-sm-4">
                  <button class="btn btn-primary" name="">Simpan</button>
                  <a href="?hal=dataCustomer" class="btn btn-warning">Kembali</a>
                </div>
              </div>
            </form>

          <?php
        }
          ?>
          </div>
        </div>
        <!-- col-lg-12-->
      </div>
  </section>
</section>