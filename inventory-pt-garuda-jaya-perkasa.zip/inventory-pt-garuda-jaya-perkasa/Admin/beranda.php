<?php
include "../koneksi.php";
include "../cek.php";
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>INVENTORY - PT. Garuda Jaya Perkasa</title>

  <!-- Favicons -->
  <link href="../img/favicon.png" rel="icon">
  <link href="../img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="../css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="../lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">

  <link href="../css/style.css" rel="stylesheet">
  <link href="../css/style-responsive.css" rel="stylesheet">
  <script src="../lib/chart-master/Chart.js"></script>

  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.php" class="logo"><b><span>PT. Garuda Jaya Perkasa</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->

        <!--  notification end -->
      </div>

      <div class="top-menu">
        <ul class="nav pull-right top-menu" style="margin-right: 25px;">
          <li>
            <div class="topbar-divider d-none d-sm-block"></div>
            <a class="logout" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="bi bi-person-circle"></i>
              <span class="centered"><?php echo $_SESSION['nama_admin'] ?></span>

            </a>
            <!-- Dropdown - User Information -->
            <div class=" logout dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
              <a class="logout2" href="beranda.php?hal=ubahAdmin&id_login=<?php echo $_SESSION['id_login'] ?>">
                <i class="bi bi-person"></i>
                Profile
              </a>
              <div class="dropdown-divider"></div>
              <a class="logout2" href="logout.php" onclick="return confirm('Anda Yakin Ingin Keluar?')">
                <i class="bi bi-box-arrow-left"></i>
                Logout
              </a>
            </div>
          </li>
        </ul>
      </div>


    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">

          <h5 class="centered" style="font-size: 20px;"><span id="tanggalwaktu"></span></h5>
          <li class="mt">
            <a class="" href="index.php">
              <i class="bi bi-house-door" style="font-size: 18px;"></i>
              <span style="font-size: 18px;">Beranda</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="bi bi-gear" style="font-size: 18px;"></i>
              <span style="font-size: 18px;">Master Data</span>
            </a>
            <ul class="sub">
              <li><a href="?hal=dataKategori"><i class="bi bi-tags"></i><span style="font-size: 16px;">Data Kategori</span></a></li>
              <li><a href="?hal=dataBarang"><i class="bi bi-box-seam"></i><span style="font-size: 16px;">Data Barang</span></a></li>
              <li><a href="?hal=dataAdmin"><i class="bi bi-person-badge"></i><span style="font-size: 16px;">Data Admin</span></a></li>
              <li><a href="?hal=dataSupplier"><i class="bi bi-building"></i><span style="font-size: 16px;">Data Supplier</span></a></li>
              <li><a href="?hal=dataCustomer"><i class="bi bi-building"></i><span style="font-size: 16px;">Data Customer</span></a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="bi bi-cash-stack" style="font-size: 18px;"></i>
              <span style="font-size: 18px;">Transaksi</span>
            </a>
            <ul class="sub">
              <li><a href="?hal=dataPenerimaan"><i class="fa fa-backward"></i><span style="font-size: 16px;">Pembelian Barang</span></a></li>
              <li><a href="?hal=dataPengeluaran"><i class="fa fa-forward"></i><span style="font-size: 16px;">Penjualan Barang</span></a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="bi bi-file-text" style="font-size: 18px;"></i>
              <span style="font-size: 18px;">Laporan</span>
            </a>
            <ul class="sub">
              <!--<li><a href="laporan/laporanBarang.php"><i class="bi bi-file-earmark-text-fill"></i><span style="font-size: 15px;">Master Barang</span></a></li>-->
              <!--<li><a href="?hal=stokBarang"><i class="bi bi-credit-card-2-front-fill"></i><span style="font-size: 16px;">Kartu Stok</span></a></li>-->
              <li><a href="?hal=laporanTransaksi"><i class="bi bi-file-earmark-text-fill"></i><span style="font-size: 16px;">Transaksi Barang</span></a></li>

            </ul>
          </li>
          <li class="submenu" style="font-size: 18px;" onclick="return confirm('Anda Yakin Ingin Keluar?')">
            <a class="logout" href="logout.php">
              <i class="bi bi-box-arrow-left"></i>
              <span style="font-size: 18px;">Logout</span>
            </a>
          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>

    <?php
    include "../koneksi.php";
    include "isi.php";

    ?>


    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../lib/jquery/jquery.min.js"></script>

  <script src="../lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="../lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../lib/jquery.scrollTo.min.js"></script>
  <script src="../lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="../lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="../lib/common-scripts.js"></script>
  <script type="text/javascript" src="../lib/gritter/js/jquery.gritter.js"></script>
  <script type="text/javascript" src="../lib/gritter-conf.js"></script>
  <!--script for this page-->
  <script src="../lib/sparkline-chart.js"></script>
  <script src="../lib/zabuto_calendar.js"></script>

  <script type="application/javascript">
    $(document).ready(function() {
      $("#date-popover").popover({
        html: true,
        trigger: "manual"
      });
      $("#date-popover").hide();
      $("#date-popover").click(function(e) {
        $(this).hide();
      });

      $("#my-calendar").zabuto_calendar({
        action: function() {
          return myDateFunction(this.id, false);
        },
        action_nav: function() {
          return myNavFunction(this.id);
        },
        ajax: {
          url: "show_data.php?action=1",
          modal: true
        },
        legend: [{
            type: "text",
            label: "Special event",
            badge: "00"
          },
          {
            type: "block",
            label: "Regular event",
          }
        ]
      });
    });

    function myNavFunction(id) {
      $("#date-popover").hide();
      var nav = $("#" + id).data("navigation");
      var to = $("#" + id).data("to");
      console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
    }
  </script>
  <script>
    var tw = new Date();
    if (tw.getTimezoneOffset() == 0)(a = tw.getTime() + (7 * 60 * 60 * 1000))
    else(a = tw.getTime());
    tw.setTime(a);
    var tahun = tw.getFullYear();
    var hari = tw.getDay();
    var bulan = tw.getMonth();
    var tanggal = tw.getDate();
    var hariarray = new Array("Minggu,", "Senin,", "Selasa,", "Rabu,", "Kamis,", "Jum'at,", "Sabtu,");
    var bulanarray = new Array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "Nopember", "Desember");
    document.getElementById("tanggalwaktu").innerHTML = hariarray[hari] + " " + tanggal + " " + bulanarray[bulan] + " " + tahun + " Jam " + ((tw.getHours() < 10) ? "0" : "") + tw.getHours() + ":" + ((tw.getMinutes() < 10) ? "0" : "") + tw.getMinutes();
  </script>

</body>

</html>