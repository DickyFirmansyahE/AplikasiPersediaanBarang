<section id="main-content">
  <section class="wrapper">


    <div class="row mt">
      <div class="col-md-12">
        <div class="content-panel">
          <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" style="width: 98%; margin-left: 1%; font-size: 15px;">
            <h4 style="font-size: 25px;"><i class="bi bi-credit-card-2-front-fill"></i> Kartu Stok</h4>
            <hr>
            <div class="text-center">
              <form class="d-flex" method="post">
                <input type="search" name="cari" placeholder="cari barang" aria-label="Search" size="30" style="font-size: 15px;">
                <button class="btn btn-primary" name="sumbit_search" type="submit" style="padding: 3px 15px; font-size: 16px;">Search</button>
              </form>
            </div>
            <br>
            <thead>
              <?php
              include "../koneksi.php";
              $query = mysqli_query($sambungin, "SELECT * FROM tbbarang left join tbkategori on tbbarang.kode_kategori = tbkategori.kode_kategori");

              ?>
              <tr>
                <th style="width: 50px">No</th>
                <th> Kode Barang</th>
                <th class="hidden-phone"> Nama Barang</th>
                <th class="hidden-phone"> Kategori</th>
                <th class="hidden-phone"> Stok Awal</th>
                <th class="hidden-phone"> Stok Kini</th>


                <th>Aksi</th>
              </tr>
            </thead>

            <tbody>
              <?php
              $page = (isset($_GET['page'])) ? (int) $_GET['page'] : 1;

              // Jumlah data per halaman
              $limit = 10;

              $limitStart = ($page - 1) * $limit;

              $query = mysqli_query($sambungin, "SELECT * FROM tbbarang left join tbkategori on tbbarang.kode_kategori = tbkategori.kode_kategori LIMIT " . $limitStart . "," . $limit);

              $no = $limitStart + 1;

              if (isset($_POST['sumbit_search'])) {
                $cari = $_POST['cari'];
                $query = mysqli_query($sambungin, "SELECT * FROM tbbarang left join tbkategori on tbbarang.kode_kategori = tbkategori.kode_kategori WHERE kode_barang LIKE '%$cari%' OR nama_barang LIKE '%$cari%' OR nama_kategori LIKE '%$cari%' ");
              }
              while ($data = mysqli_fetch_array($query)) {
                //menghitung stok masuk
                error_reporting(0);
                $jumlahBarangTerima = "SELECT SUM(jumlah_barang) AS jumlah_barang FROM tbdetail_penerimaan where kode_barang = '$data[kode_barang]'";
                $hasilBarangMasuk = @mysqli_query($sambungin, $jumlahBarangTerima) or die(mysqli_error());
                $barangTerima = mysqli_fetch_array($hasilBarangMasuk);

                //menghitung stok keluar

                $jumlahBarangKeluar = "SELECT SUM(jumlah_barang) AS jumlah_barang FROM tbdetail_pengeluaran where kode_barang = '$data[kode_barang]'";
                $hasilBarangKeluar = @mysqli_query($sambungin, $jumlahBarangKeluar) or die(mysqli_error());
                $barangKeluar = mysqli_fetch_array($hasilBarangKeluar);

              ?>

                <tr>
                <td><?php echo $no++ ?></td>
                <td class="hidden-phone"><?php echo $data['kode_barang'] ?></td>
                <td class="hidden-phone"><?php echo $data['nama_barang'] ?></td>
                <td class="hidden-phone"><?php echo $data['nama_kategori'] ?></td>
                <td class="hidden-phone"><?php echo $data['stok'] ?></td>
                <td class="hidden-phone"><?php echo $data['stok'] + $barangTerima['jumlah_barang'] - $barangKeluar['jumlah_barang'] ?></td>
                <td>

                  <a href="beranda.php?hal=detailStokBarang&kode_barang=<?php echo $data['kode_barang'] ?>" class="btn btn-info btn-xs"><i class="fa fa-bars "> histori</i></a>
                </td>
                </tr>
              <?php
              }
              ?>
            </tbody>
          </table>

          <div class="text-center">
            <ul class="pagination">
              <?php
              // Jika page = 1, maka LinkPrev disable
              if ($page == 1) {
              ?>
                <!-- link Previous Page disable -->
                <li class="disabled"><a href="#">Previous</a></li>
              <?php
              } else {
                $LinkPrev = ($page > 1) ? $page - 1 : 1;
              ?>
                <!-- link Previous Page -->
                <li><a href="beranda.php?hal=stokBarang&page=<?php echo $LinkPrev; ?>">Previous</a></li>
              <?php
              }
              ?>

              <?php
              $query = mysqli_query($sambungin, "SELECT * FROM tbbarang");

              //Hitung semua jumlah data yang berada pada tabel Sisawa
              $JumlahData = mysqli_num_rows($query);

              // Hitung jumlah halaman yang tersedia
              $jumlahPage = ceil($JumlahData / $limit);

              // Jumlah link number 
              $jumlahNumber = 10;

              // Untuk awal link number
              $startNumber = ($page > $jumlahNumber) ? $page - $jumlahNumber : 1;

              // Untuk akhir link number
              $endNumber = ($page < ($jumlahPage - $jumlahNumber)) ? $page + $jumlahNumber : $jumlahPage;

              for ($i = $startNumber; $i <= $endNumber; $i++) {
                $linkActive = ($page == $i) ? ' class="active"' : '';
              ?>
                <li<?php echo $linkActive; ?>><a href="beranda.php?hal=stokBarang&page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                <?php
              }
                ?>

                <!-- link Next Page -->
                <?php
                if ($page == $jumlahPage) {
                ?>
                  <li class="disabled"><a href="#">Next</a></li>
                <?php
                } else {
                  $linkNext = ($page < $jumlahPage) ? $page + 1 : $jumlahPage;
                ?>
                  <li><a href="beranda.php?hal=stokBarang&page=<?php echo $linkNext; ?>">Next</a></li>
                <?php
                }
                ?>
            </ul>
          </div>


        </div>
        <!-- /content-panel -->
      </div>
      <!-- /col-md-12 -->
    </div>


  </section>
</section>