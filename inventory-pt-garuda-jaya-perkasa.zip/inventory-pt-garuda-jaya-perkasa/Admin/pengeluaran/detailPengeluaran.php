<?php
include "../koneksi.php";
include "fungsiTanggal.php";
$kode_keluar = $_GET['kode_keluar'];

$dataAtas = mysqli_query($sambungin, "SELECT * FROM tbpengeluaran left join tbcustomer on tbpengeluaran.kode_customer = tbcustomer.kode_customer where kode_keluar = '$kode_keluar'");
$x = mysqli_fetch_array($dataAtas);
?>


<section id="main-content">
	<section class="wrapper">
		<div class="col-lg-12 mt">
			<div class="row content-panel">
				<div class="col-lg-10 col-lg-offset-1">
					<div class="pull-left">
						<h2>Detail Pengeluaran Barang</h2>
					</div>
					<div class="clearfix"></div>
					<div class="row">
						<div class="col-md-5" style="font-size: 15px;">

							<div>
								<div class="pull-left">NOMOR FAKTUR :</div>
								<div class="pull-right"><?php echo $x['kode_keluar'] ?> </div>
								<div class="clearfix"></div>
							</div>
							<div>
								<div class="pull-left">TANGGAL :</div>
								<div class="pull-right"><?php echo tgl_indo($x['tanggal_keluar']); ?></div>
								<div class="clearfix"></div>
							</div>
							<div>
								<div class="pull-left">CUSTOMER :</div>
								<div class="pull-right"><?php echo $x['nama_customer'] ?> </div>
								<div class="clearfix"></div>
							</div>
							<div>
								<div class="pull-left">JUMLAH ITEM :</div>
								<div class="pull-right"><?php echo $x['jumlah_item'] ?> </div>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>
					<br>
					<table class="table" style="font-size: 15px;">
						<thead>
							<?php
							include "../koneksi.php";
							$dataBawah = mysqli_query($sambungin, "SELECT * FROM tbpengeluaran left join tbdetail_pengeluaran on tbpengeluaran.kode_keluar = tbdetail_pengeluaran.kode_keluar left join tbbarang on tbdetail_pengeluaran.kode_barang = tbbarang.kode_barang where tbpengeluaran.kode_keluar = '$kode_keluar'");
							?>
							<tr>
								<th style="width: 50px">No</th>
								<th style="width: 150px">KODE BARANG</th>
								<th class="text-left" style="width: 450px">NAMA BARANG</th>
								<th style="width: 150px">SATUAN</th>
								<th style="width: 50px">QTY</th>
								<th style="width: 50px"></th>
								<th style="width: 150px">HARGA SATUAN</th>
								<th style="width: 50px"></th>
								<th style="width: 150px">JUMLAH</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$no = 0;
							$total_harga_satuan = 0;
							while ($data = mysqli_fetch_array($dataBawah)) {
								$no++;
								$jumlahharga = $data['jumlah_barang'] * $data['harga_satuan'];
								$total_harga_satuan += $jumlahharga;
							?>
								<tr>
									<td><?php echo $no ?></td>
									<td><?php echo $data['kode_barang'] ?></td>
									<td><?php echo $data['nama_barang'] ?></td>
									<td><?php echo $data['satuan'] ?></td>
									<td><?php echo $data['jumlah_barang'] ?></td>
									<td>X</td>
									<td>Rp.<?php echo number_format($data['harga_satuan']) ?></td>
									<td>=</td>
									<td>Rp.<?php echo number_format($jumlahharga) ?></td>
								</tr>
							<?php
							}
							?>
							<tr>
								<th>TOTAL</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td>Rp.<?php echo number_format($total_harga_satuan) ?></td>
							</tr>
						</tbody>

					</table>
					<div class="form-group">
						<div class="col-sm-4">
							<a href="beranda.php?hal=dataPengeluaran" class="btn btn-info">Kembali</a>
						</div>

					</div>
				</div>

			</div>

		</div>
	</section>
</section>