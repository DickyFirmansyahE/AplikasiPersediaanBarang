<section id="main-content">
 <section class="wrapper">


<div class="row ">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="bi bi-credit-card-2-front-fill"></i> Kartu Stok</h4>
                <hr>
               
                <br>
                <thead>
                   <?php
                      include "../koneksi.php";
                      include "fungsiTanggal.php";
                      


                      $query = mysqli_query($sambungin,"SELECT * FROM tbgabung_transaksi left join tbbarang on tbbarang.kode_barang = tbgabung_transaksi.kode_barang  
                      group by tbgabung_transaksi.tanggal,tbbarang.kode_barang");
                      
                      $totalMasuk = 0;
                      $totalKeluar = 0;

 								     
                    ?>
                  <tr>
                  <th class="hidden-phone"><i class="fa fa-calendar"></i>Tanggal</th>
                    <th> Kode Barang</th>
                    <th class="hidden-phone"> Nama Barang</th>
                    <th class="hidden-phone"> Stok Awal</th>
                    <th> Barang Masuk</th>
 									  <th> Barang Keluar</th>
                    <th class="hidden-phone"> Stok Kini</th>
                  </tr>
                </thead>

                <tbody>
                  <?php
                    while($data = mysqli_fetch_array($query)){
                        //menghitung stok masuk
                        $z = mysqli_query($sambungin,"SELECT * FROM tbbarang where kode_barang = '$data[kode_barang]'");
                        $x = mysqli_fetch_array($z);
                
 							$sqlMasuk = "SELECT SUM(jumlah_barang) as total FROM tbgabung_transaksi left join tbbarang on tbgabung_transaksi.kode_barang = tbbarang.kode_barang
                 where tbgabung_transaksi.kode_barang = '$data[kode_barang]'  AND tanggal = '$data[tanggal]' AND ket = 'MASUK' group by tbgabung_transaksi.tanggal";
 							$hasilMasuk = mysqli_query($sambungin,$sqlMasuk);
 							$a = mysqli_fetch_array($hasilMasuk);

 							$sqlKeluar = "SELECT SUM(jumlah_barang) as total FROM tbgabung_transaksi left join tbbarang on tbgabung_transaksi.kode_barang = tbbarang.kode_barang
                where tbgabung_transaksi.kode_barang ='$data[kode_barang]'  AND tanggal = '$data[tanggal]' AND ket = 'KELUAR' group by tbgabung_transaksi.tanggal";
 							$hasilKeluar = mysqli_query($sambungin,$sqlKeluar);
 							$b = mysqli_fetch_array($hasilKeluar);

 							//jumlahkan semua total masuk dan keluar
 							$totalMasuk += $a['total'];
 							$totalKeluar += $b['total'];
 							$stokSisa = $data['stok'] + $a['total'] - $b['total'];

 							?>
                   <tr>
                   <td><?php echo tgl_indo($data['tanggal']) ?></td>
                    <td class="hidden-phone"><?php echo $data['kode_barang'] ?></td>
                     <td class="hidden-phone"><?php echo $data['nama_barang'] ?></td>  
                     <td class="hidden-phone"><?php echo $data['stok'] ?></td>
                     <td><?php echo  $a['total']; ?></td>
								      <td><?php echo $b['total']; ?></td>
                      <td class="hidden-phone"><?php echo $stokSisa ?></td>  
                  </tr>
                    <?php
                }
              ?>
              
                </tbody>
              </table>
              
             

            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>


</section>
</section>